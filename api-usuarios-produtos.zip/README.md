# 🚀 API de Gestão de Usuários e Produtos

API REST com Node.js, Express, Prisma e PostgreSQL.

## Como rodar:
```
npm install
npx prisma migrate dev --name init
npm run dev
```
